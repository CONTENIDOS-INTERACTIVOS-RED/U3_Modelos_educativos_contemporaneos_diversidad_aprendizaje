<template lang="pug">
.curso-main-container.introduccion
  BannerInterno(subTitulo="Introducción")
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .row.mb-5       
      .col-lg-8.mb-3.mb-lg-0 
        .bg-color-6.p-4.mb-4(data-aos="fade-left")
          p.mb-0 En el sistema educativo actual, los docentes deben desarrollar nuevas habilidades para enfrentar un entorno saturado de información y marcado por la diversidad de saberes y contextos. La expansión de la conectividad exige formar ciudadanos críticos, analíticos y reflexivos capaces de interactuar con este flujo constante de datos de manera consciente y significativa.
        p(data-aos="fade-down") La rápida transformación educativa ha dado paso a metodologías activas y participativas, que sitúan al estudiante como protagonista del aprendizaje. Estas herramientas innovadoras, basadas en tecnología y análisis de datos, son claves para trascender las formas tradicionales de enseñanza y formar ciudadanos conectados, pero con pensamiento crítico ante su realidad inmediata.

      .col-lg-4
        figure
          img.img-a.img-t(src="@/assets/curso/temas/1.png", data-aos="zoom-in") 

    .bg-full-width.bg-color-3(data-aos="fade-down")
      .px-4.px-md-5.py-4
        .row.align-items-center
          .col-lg-auto
            img.img-a.img-t(src="@/assets/curso/temas/2.svg")
          .col-lg
            p.mb-0 Esta unidad se enfoca en la aplicación de herramientas digitales y metodologías activas, adaptables a cualquier nivel, edad o contexto educativo. Su objetivo es potenciar la enseñanza integradora, promoviendo habilidades actuales y respondiendo a la diversidad. Para ello, se requiere del docente creatividad, análisis y planificación para elegir herramientas pertinentes que conecten los saberes con el entorno y el potencial del estudiante.
</template>
