<template lang="pug">
  .curso-main-container.creditos-vista
    BannerInterno(subTitulo="SÍNTESIS")
    .container.tarjeta.tarjeta--blanca.p-4.p-md-5
      p(data-aos="fade-up").mb-5 La Unidad 3 Innovación y tecnología en la educación, de la asignatura Modelos Educativos Contemporáneos y Diversidad en el Aprendizaje, está dedicada a la aplicación de herramientas digitales y metodologías activas en la enseñanza, tales como la #[b gamificación y el aprendizaje basado en proyectos y retos.] 

      .row.justify-content-center
        .col-lg-12.mb-5
          figure.bg-color-sintesis.p-5.brounded
            img(src='@/assets/curso/sintesis.svg', alt='', data-aos="zoom-in")
</template>
